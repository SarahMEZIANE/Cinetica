export const user =  {
    username: 'admin@cinetica.com',
    password: '$2y$10$NtzFwms7SpskI2LCbBGAkORk7Hxd2eUbJARB/7BOj.AXTyclnh1rK',
};
