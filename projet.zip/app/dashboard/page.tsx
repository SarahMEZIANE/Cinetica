'use client'
import React, { useEffect } from 'react';
import MovieSlider from './movies/MovieSlider';
import { usePopularMovies } from '@/hooks/usePopularMovies';

const Dashboard = () => {
  const { movies, loading, error, fetchMovies } = usePopularMovies();

  useEffect(() => {
    fetchMovies();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-transparent text-white flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-yellow"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="text-red-500 text-xl">{error}</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-transparent text-white">
      <header className="py-6 px-8">
        <h1 className="text-3xl font-bold">Movie Dashboard</h1>
      </header>

      <main className="container py-8 space-y-12">
        <MovieSlider 
          title="Popular Movies" 
          movies={movies} 
        />
      </main>
    </div>
  );
};

export default Dashboard;