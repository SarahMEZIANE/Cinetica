import React from 'react';
import { useMovieSlider } from '@/hooks/useMovieSlider';
import { Movie } from '@/app/entites/Movie';
import MovieCard from './MoviesCard';
import SliderControls from './SliderControls';

interface MovieSliderProps {
  movies: Movie[];
  title: string;
}

const MovieSlider: React.FC<MovieSliderProps> = ({ movies, title }) => {
  const {
    sliderRef,
    canScrollLeft,
    canScrollRight,
    scrollLeft,
    scrollRight
  } = useMovieSlider();

  return (
    <div className="relative w-full py-4">
      <h2 className="text-2xl font-bold mb-4 px-4">{title}</h2>
      
      <div className="relative group">
        <div
          ref={sliderRef}
          className="flex gap-4 overflow-x-hidden scroll-smooth px-4"
        >
          {movies.map((movie) => (
            <div key={movie.id} className="flex-none w-40">
              <MovieCard title={movie.title} posterPath={movie.poster_path} rating={movie.vote_average} overview={movie.overview} release_date={movie.release_date} />
            </div>
          ))}
        </div>

        <SliderControls
          canScrollLeft={canScrollLeft}
          canScrollRight={canScrollRight}
          onScrollLeft={scrollLeft}
          onScrollRight={scrollRight}
        />
      </div>
    </div>
  );
};

export default MovieSlider;