'use client';
// app/dashboard/page.tsx

import React from 'react';


export default function MovieSlider() {
  return (
    <div className="space-y-8 py-6">
    </div>
  );
}