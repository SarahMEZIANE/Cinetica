export const user =  {
    username: 'admin@cinetica.com',
    password: '$2y$10$JRBLbyactwGE1GsDulNxOO0VyvbtrW1pf8yP6TRrDY454IbZe4BIO',
};
