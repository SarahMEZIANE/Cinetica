// app/metadata.ts (Server component, does not need "use client")
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Cinetica",
  description: "ING2 INFOA PWA",
};
