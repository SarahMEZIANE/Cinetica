import { signIn } from 'next-auth/react';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

interface Credentials {
    username: string;
    password: string;
}

export function useLogin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const router = useRouter();

    const handleSubmit = async (credentials: Credentials) => {
        setError('');
        
        try {
            const result = await signIn('credentials', {
                ...credentials,
                callbackUrl: '/dashboard',
                redirect: false,
            });

            console.log("SignIn result:", result);

            if (result?.ok) {
                router.push('/dashboard');
            } else {
                setError('Identifiants incorrects');
            }
        } catch (e) {
            console.error("Login error:", e);
            setError('Erreur de connexion');
        }
    };

    return {
      username,
      setUsername,
      password,
      setPassword,
      error,
      handleSubmit
    };
}
