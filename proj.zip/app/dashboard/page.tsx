'use client'
import DashboardLayout from "@/app/dashboard/DashboardLayout";

const DashboardPage = () => {
  return (
    <DashboardLayout>
          <h1 className="text-3xl font-semibold text-gray-700 dark:text-white">En cours de développement ...</h1>
          </DashboardLayout>
  );
};

export default DashboardPage;
