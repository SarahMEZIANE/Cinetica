
export interface Person {
    id: number;
    name: string;
    profile_path: string;
    job: string;
    character: string;
  order: number;
  }

export default Person;