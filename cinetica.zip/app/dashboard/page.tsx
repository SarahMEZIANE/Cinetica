const DashboardPage = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold">Welcome to the Dashboard</h1>
      <p>Select an option from the sidebar to begin.</p>
    </div>
  );
};

export default DashboardPage;
